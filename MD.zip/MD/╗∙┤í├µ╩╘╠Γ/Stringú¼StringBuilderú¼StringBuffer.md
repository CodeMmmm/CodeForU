    String是引用类型，是不可改变
    
    StringBuilder（线程不安全），可变
    
    StringBuffer（线程安全），可变
    
    注意：'+'拼接字符串本质上就是调用StringBuilder，效率较StringBuilder和StringBUffer低，因为其内部每次都会new StringBuilder