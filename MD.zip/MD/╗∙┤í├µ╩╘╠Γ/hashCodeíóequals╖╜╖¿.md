# Object类中

    hashCode方法（本地方法）是返回对象的地址值，
    equals方法是比较两个对象的地址值（==）
    
# 重写
    equals方法就是比较两个对象的属性是否相等
    
    注意：
        如果equals方法为true，则hashCode一定相同
        hashCode相同，equals方法不一定为true
        
    HashSet：元素唯一且无序
        
        源码：
            先比较hashCode，不相同则存入集合。
            相同调用equals方法，为true则重复，fasle则存入集合
            
        所以存入HashSet中的对象一定要重写hashCode和equals方法