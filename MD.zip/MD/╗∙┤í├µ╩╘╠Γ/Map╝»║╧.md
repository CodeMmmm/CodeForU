# 1.map集合的遍历方式
    
    ①. keySet()，根据键找值
    ②. entrySet(),使用迭代器遍历，根据entry得到各自的key和value
    ③. 使用增强for遍历出entry，找到值和key
    ④. values()，直接得到所有的值，拿不到key

# 2. map的实现类

    TreeMap：使用二叉树存储key-value
    
    HashTable：线程安全，效率低，不能使用null作为key和value
    
    HashMap：线程不安全，效率高，能使用null作为key和value
    
    Properties：使用key-value存储

# 3. HashMap、HashSet的数据结构
    
    数组加链表：数组中的每个元素索引对应的是HashCode&（length-1）的序号，每个元素上对应链表存放key（对应也有值）或set中的值。
    
    注意：
    1.当数组元素存放超过 负载因子*数组长度 的值时，会再次扩容数组（就是搞个新数组，然后复制），一般是扩为之前的两倍。
    
    2.hashcode是找到对应数组的索引，然后通过euqals方法比较其链表上的元素，一样则覆盖，不一样则直接加入。
    
    3.jdk1.8后，引入了二叉树，方便查询。因为当链表上元素太多时，不方便查询。
    
    4.hashmap扩容为什么是2的幂次，减少hash碰撞。hashmap根据二进制运算得出数组的位置，如果是2的幂次的话，-1后的二进制数为..1111，如果为15的话，二进制数为1110。很明显，做&操作的时候，2的幂次能减少碰撞。
    
# HashMap在高并发下如果没有处理线程安全会有怎样的安全隐患，具体表现是什么

    1.多线程执行put时可能导致get无限循环，具体表现cpu利用率100%
        因为多线程操作时，hashmap可能会扩容，进行数组迁移，迁移就是rehash，多线程操作时可能造成循环链表。所以get时，可能无限循环
    
    2.多线程put时造成元素丢失
        因为多线程put执行addEntry，可能产生hash碰撞，导致元素覆盖丢失
        
    解决：使用线程安全的map：如hashTable，ConcurrentHashMap
    
# ConcurrentHashMap多线程下比HashTable效率更高

    多线程访问HashTable时，多个线程竞争一把锁，造成线程堵塞。
    ConcurrentHashMap将一个HashMap分段，支持多线程访问。
        