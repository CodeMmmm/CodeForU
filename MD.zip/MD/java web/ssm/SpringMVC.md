#  执行流程

    1.用户发送请求到前端控制器（DispatcherServlet），前端控制器调用处理器映射器（HandlerMapping）请求Handler。
    2.处理器映射器根据请求url，找到具体处理器，生成处理器对象（Handler）以及处理器拦截器（有则生成），返回给前端控制器
    3.前端控制器调用处理器适配器（HandlerAdapter）请求执行handler，适配器适配后，调用具体处理器（Handler，也称后端控制器），返回ModelAndView，适配器再返回给前端控制器
    4.前端控制器传递ModelAnd View给视图解析器（ViewResolver）进行解析，返回具体View
    5.前端控制器对View进行渲染（将模型数据填充到视图），并响应用户