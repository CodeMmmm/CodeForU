# #{}和${}的区别
    
    #{}是占位符，防止sql注入，在编译的时候写成？，调用set方法赋值。
    传递的如果是简单类型，括号里写任意名称，是pojo则需要写对象的属性名称。可以对数据自动类型转换
    
    ${}是连接符，替换成变量的值，例如like "%${..}%"
    简单类型，括号中写value，pojo则写对象属性名。将所有数据都当成字符串处理，

# 实体类中的属性名和表中的字段名不一致

    1. 在sql语句中对字段取别名使其和实体类中属性名一致。
    2. 在resultmap中映射字段名，使其和实体类中属性名一致
    
# 模糊查询like如何写
    
    1. 在传入参数前手动加入%%
    2. 在sql语句中，大括号外面加上%%
    
# 获取自动生成的主键

    selectKey：返回自增主键
        新建selectKey标签，写在其中
       属性： 
              keyColumn：查询的列
              keyProperty：将查询的结果赋值给pojo的哪个属性
              resultType：返回值类型
              order:sql语句执行的先后顺序

       mysql函数：select last_insert_id(),获取最后一次插入数据的id
       
# mapper中如何传递多个参数

    1. 使用占位符的思想
    
        使用#{0}，#{1}，0表示传入的第一个参数，1表示第二个，一次类推
        
        或者在接口mapper中使用@param注解命名参数，sql语句中直接使用即可。
    
    2，使用map集合作为装载
    
        传入map，sql语句中写key，会自动在map找值
        
# 动态sql

    执行原理为，使用OGNL从sql参数对象中计算表达式的值，根据表达式的值动态拼接sql，以此来完成动态sql的功能。
    
    常见的标签有if，where，foreach，trim等

# 不同的映射文件中，相同id是否会覆盖

    取决于是否设置了namespace，没有则会覆盖
    
# mysql为什么是半自动ORM映射工具

    因为需要手动写sql语句，hibernate是全自动，不需要写sql语句
    
# dao接口的工作原理，以及方法参数不同时，能实现重载吗
    
    Dao接口的工作原理是JDK动态代理，Mybatis运行时会使用JDK动态代理为Dao接口生成代理proxy对象，代理对象proxy会拦截接口方法，转而执行MappedStatement所代表的sql，然后将sql执行结果返回。
    
    不能重载，因为是根据全限定名+接口方法名寻找MappedStatement。所以全限定名对应namespace，方法名对应id
    
# mybatis相比较ibatis改进

    1.接口绑定，注解绑定sql和xml绑定sql
    2.动态sql由以前的节点配置改为表达式
    3.引入高级映射，一对一是association，一对多是collection
    
# 接口绑定的实现方式

    1.注解实现：直接在接口的方法上添加注解，例如@Select等
    2.xml实现：namespace必须为接口的全限定名，sql的id为接口的方法名
    
# 延迟加载

    就是按需加载，只支持高级映射，配置lazyLoadingEnabled=true
    
    实现原理: 使用cglib代理创建目标对象的代理对象，调用目标方法时，进入拦截器方法。
    比如a.getB().getName(),拦截器invoke方法发现a.getB是null，就会单独发送事先保存好的单独查询关联B对象的sql，得到结果后，调用a.setB()赋值，然后完成a.getB().getName()的调用
    
# 缓存

    一级缓存：sqlsession级别，同一个会话相同sql语句从缓存中读取
    二级缓存：mapper级别，根据namespace分配内存空间