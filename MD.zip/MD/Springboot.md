# 优点
    
    1.独立运行：内嵌各种Servlet容器，tomcat，Jetty等，无需打成war包，所有依赖打成一个jar包即可
    2.简化配置：自动依赖其他组件，减少maven配置  
    3.自动配置：可根据当前类路径的类，jar包自动配置bean
    4.无代码生成和XML配置：无代码生成，无需xml完成配置
    
# 核心注解

    @SpringBootApplication，其注解下包含三个注解
    
        1.@SpringBootConfiguration：组合了@Configuration，等同于配置文件功能
        2.@EnableAutoConfiguration:开启自动配置，内部去加载META-INF/Spring.factories文件的信息，筛选出以EnableAutoConfiguration为key的数据，加载到IOC容器中，完成自动配置
        此项也可以关闭某项自动配置，例如关闭数据源自动配置
        3.@ComponentScan:spring组件扫描
        
# 运行springboot
    
    1.打包用命令或者放到容器中运行
    2.直接执行main方法
    3.用Maven/Gradle插件运行
    
# 启动springboot的时候运行特定代码

    实现ApplicationRunner或CommandLineRunner接口，重写run方法
    
    如果需要指定顺序，实现Ordered接口或使用Order注解
    
# 读取配置文件的方式
    
    1.使用@Vale注解
    2.@ConfigurationProperties注解，类上，读取某个对象
    3.@PropertySource + @Value 不能读取yml文件
    4.Environment，只需在类中注入该对象，使用getProperty(String key)方式即可
    