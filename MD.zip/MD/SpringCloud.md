# 注册中心Eureka

    1.服务提供者向注册中心注册服务
    2.服务消费者向注册中心订阅服务，注册中心将对应服务的提供者地址列表发送给消费者，并且定时更新
    3.消费者调用服务
    
    注意：心跳（续约）：服务提供者定期通过http方式向Eureka刷新自己状态
    
    失效剔除：服务中心每隔一段时间会将未续约服务剔除
    
    自我保护：最近15分钟服务续约的比例是否低于85%，是则触发自我保护
    
        1.自我保护模式下，不会剔除任何服务实例
        2.保证了大部分服务可用
        3.通过enable-self-preservation配置可用关停自我保护，默认值是打开
        
# 负载均衡Ribbon

    负载均衡器：
    # 修改服务地址轮询策略，默认是轮询，配置之后变随机
    user-provider:
      ribbon:
        #轮询
        #NFLoadBalancerRuleClassName: com.netflix.loadbalancer.RoundRobinRule
        #随机算法
        #NFLoadBalancerRuleClassName: com.netflix.loadbalancer.RandomRule
        #重试算法,该算法先按照轮询的策略获取服务,如果获取服务失败则在指定的时间内会进行重试，获取可用的服务
        #NFLoadBalancerRuleClassName: com.netflix.loadbalancer.RetryRule
        #加权法,会根据平均响应时间计算所有服务的权重，响应时间越快服务权重越大被选中的概率越大。刚启动时如果同统计信息不足，则使用轮询的策略，等统计信息足够会切换到自身规则。
        NFLoadBalancerRuleClassName:        com.netflix.loadbalancer.ZoneAvoidanceRule

# 熔断器

状态及原理分析：

    关闭状态：所有请求正常访问
    全开状态：所有请求降级处理，非永久，打开一会后进入休眠时间（默认5秒），然后进入半开状态
    半开状态：判断下一次请求的状态，成功则关闭，失败则切回全开
    
    当一定时间请求失败百分比达到阈值，则触发熔断。默认比例是50%，请求次数不低于20

核心：

    线程隔离：Hystrix为每个依赖服务调用一个小的线程池，线程池被用尽，调用立即被拒绝。默认不使用排队。
    
    服务降级（兜底方法）：线程池用尽或请求超时
    
降级方法：

    1.可以在服务方法是指定降级方法
    
    2.也可以在类上统一指定降级方法
    
# 远程调用Feign

    1.引入Feign依赖包
    2.创建Feign接口,feign接口中需要指定调用的服务名字
    3.使用@EnabledFeignClients启用Feign功能
    
    远程调用服务，继承了RestTemplae，集成了负载均衡，熔断处理（创建类实现feign接口，类中降级方法，在feign上指定实现类），压缩配置，日志配置
    
# 网关Gateway

    本身也是一个微服务，需要注册到Eureka，用于过滤、路由
    
    动态路由，配置文件中写路由的服务名称
    
过滤器：

    默认过滤器：
    
        AddRequestHeader：对匹配上的请求加上Header
        AddRequestParameters：对匹配上的请求路由
        AddResponseHeader：对从网关返回的响应添加Header（全局过滤器）
        ==StripPrefix==：对匹配上的请求路径去除前缀（局部过滤器）
        ...
        
    自定义过滤器：
    
        全局：实现GlobalFilter,orederd
        局部：继承AbstractGatewayFilterFactory类

# 配置中心Config

    便于管理各个微服务的配置文件，本质上也是一个微服务，可放在本地或者远程仓库
    
    需要在application.yml配置文件中指定需要远程更新的仓库地址。
    
    微服务从配置中心获取修改的配置
    
# 消息总线Spring Cloud Bus

    基于RabbitMQ实现，默认使用本地的消息队列服务
